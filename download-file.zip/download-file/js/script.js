
// Mixing jQuery and Node.js code in the same file? Yes please!

$(function(){


	var fs = require('fs');
	var validUrl = require('valid-url');	
	var path = require('path');    
   

	$("#download-btn").on("click",function(){
		var downURL="";
		$("#download-status").text("");
		clearStats();
		downURL=$.trim($("#url").val());
		console.log("downURL "+downURL);
		
		if(downURL!=""){
			if(validUrl.isUri(downURL)){	
				console.log("isURL ");			
				
				//downURL=path.resolve(__dirname, 'elastic.pdf');
				//console.log("downURL "+downURL);
				downloadFile(downURL, path);
				
			}else{
				alert("Please enter Valid URL!");	
			}
		
		}else{
			alert("Please enter Download URL!");	
		}		
			
	});
	
	
	
	
	
	
});



function downloadFile(filePath, path){
	
	var Downloader = require('mt-files-downloader');
	var mime = require('mime');
    // Create new downloader
    var downloader = new Downloader();
    
    // Download example file and save it to directory
    var fileUrl = filePath;
	
	
	 var filename = path.basename(fileUrl);
	var mimetype = mime.lookup(fileUrl);
	console.log('filename - '+ filename);
	console.log('mimetype - '+ mimetype);
	
    var fileSavePath = path.join(__dirname+'/downloaded', filename);
    
    // Create new download
    var dl = downloader.download(fileUrl, fileSavePath);
    
    // Optionnal, set retry options
    dl.setRetryOptions({
        maxRetries: 3,        // Default: 5
        retryInterval: 1000 // Default: 2000
    });
    
    // Optional, set download options
    dl.setOptions({
        threadsCount: 5, // Default: 2, Set the total number of download threads
        method: 'GET',      // Default: GET, HTTP method
        port: 80,          // Default: 80, HTTP port
        timeout: 5000,   // Default: 5000, If no data is received, the download times out (milliseconds)
        range: '0-100',  // Default: 0-100, Control the part of file that needs to be downloaded.
    });
    
    // Called when the download will start
    dl.on('start', function() {
        console.log('EVENT - Download started !');
		console.log('Stats : '+Downloader.Formatters);
		
        // You can call dl.getStats() when you want to get the download stats
        // If you call dl.stop(), the download will be paused. You can then call dl.resume() to resume it.
        // To cancel a download and remove his files, call dl.destroy().
    });
    
    // Called in case of error
    dl.on('error', function() {
        console.log('EVENT - Download error !');
        console.log(dl.error);
    });
    
    // Called when the download is finished
    dl.on('end', function() {
        console.log('EVENT - Download finished !');
		clearStats();
        console.log(dl.getStats());
    });
    

    // Start the download
    dl.start();
	
	// Import generic examples for handling events and printing stats
	require('./js/_handleEvents')(dl);
	require('./js/_printStats')(dl);

}



function statusDisplay(text){		
	$("#download-status").text(text);
}
function progressDisplay(progress){		
	$("#download-progress").text(progress);
}
function speedDisplay(speed){		
	$("#download-speed").text(speed);
}
function elapsedtimeDisplay(time){		
	$("#download-elapsed-time").text(time);
}
function etaDisplay(time){		
	$("#download-eta").text(time);
}

function clearStats(){	
	$("#download-progress").text("");
	$("#download-speed").text("");
	$("#download-elapsed-time").text("");
	$("#download-eta").text("");
}